
# Personal Bio Website

This is a personal portfolio-style static website containing:

- 📄 Dashboard (`index.html`)
- 👤 Personal Details (`detail.html`)
- 📞 Contact Page (`contact.html`)
- 🖼️ Image Gallery (`gallery.html`)

## 📦 Structure

```
/PersonalBioWebsite
│
├── index.html
├── detail.html
├── contact.html
├── gallery.html
├── m.jpeg
├── WhatsApp Image ... (gallery images)
└── README.md
```

## 🚀 How to Deploy (GitHub Pages)

1. Create a new repository on [GitHub](https://github.com).
2. Upload all the files from this ZIP.
3. Commit and push your changes.
4. Go to **Settings > Pages** and set the source to the main branch root.
5. Your site will be live at: `https://your-username.github.io/repository-name/`

## 🌐 Alternative Hosting

You can also drag and drop this folder into:
- [Netlify Drop](https://app.netlify.com/drop)
- [Vercel](https://vercel.com/)
- [Firebase Hosting](https://firebase.google.com/docs/hosting)

## 📞 Features

- Interactive contact section with call & message simulation.
- Responsive and animated gallery.
- Simple and fast-loading static layout.
